<?php return array(
    'dependencies' => array(
        'wc-blocks-checkout',
        'wc-blocks-registry',
        'wc-settings',
        'wp-api-fetch',
        'wp-element',
        'wp-html-entities',
        'wp-i18n',
    ),
    'version' => '2.1.0',
);
