<?php
$environments = array();
$environments["staging"]     =    array(
    "api_url"    =>    "https://pay.staging.teljoy.co.za/api/",
);

$environments["production"] =    array(
    "api_url"    =>    "https://pay.teljoy.co.za/api/",
);
